# Documento: Reglas de Negocio

## 1. Objetivos del Documento
Establecer las reglas lógicas e inmutables que norman el comportamiento del sistema **Almacenes al Costo**.

## 2. Reglas del Negocio (MVP)
*   **RN-01: Compra Sin Cuenta Obligatoria**: Un cliente puede buscar, seleccionar y comprar productos sin tener una cuenta registrada previamente en la plataforma.
*   **RN-02: Flujo de Métodos de Pago**: El sistema de ventas del MVP acepta tres métodos de pago durante el Checkout: 1. Tarjeta (Pasarela de pagos en línea), 2. Transferencia Bancaria, 3. Deuna. El cliente elige libremente el método.
*   **RN-03: Validación Manual Reservada**: La validación visual de comprobantes por parte del Administrador aplica únicamente para los métodos de Transferencia Bancaria y Deuna. El pedido se guarda como "Validando" al subir el comprobante y cambia a "Aprobado" tras la confirmación manual de fondos.
*   **RN-04: Procesamiento Automatizado de Tarjeta**: Si el cliente paga con Tarjeta, el sistema procesa el cobro mediante la pasarela segura. Al recibir la notificación exitosa de la pasarela (Webhook o Callback), el pedido cambia automáticamente al estado "PAGADO" y descuenta inmediatamente el stock físico de inventario.
*   **RN-05: Registro Opcional Post-Compra**: El cliente puede opcionalmente registrar una contraseña para crear su cuenta al finalizar la compra, heredando los datos ingresados en el checkout.
*   **RN-06: Bloqueo Temporal de Stock en Pasarela**: Al iniciar una transacción con Tarjeta, el stock se reserva temporalmente por 15 minutos. Si el pago falla o expira, el stock se devuelve al inventario físico. Si el pago es exitoso, la reserva se consolida como descuento definitivo.

## 3. Referencias y Dependencias
*   [01-business/README.md](file:///c:/xampp/htdocs/Almacenes-al-Costo/spec/01-business/README.md)
*   [11-decisions/README.md](file:///c:/xampp/htdocs/Almacenes-al-Costo/spec/11-decisions/README.md)
*   [02-requirements/README.md](file:///c:/xampp/htdocs/Almacenes-al-Costo/spec/02-requirements/README.md)
