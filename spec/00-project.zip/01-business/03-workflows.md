# Documento: Flujos de Procesos y Workflows

## 1. Objetivos del Documento
Diagramar y detallar paso a paso los procesos lógicos y operativos de la aplicación **Almacenes al Costo**.

## 2. Flujo del Checkout Inteligente y Validación
## 2. Flujo de Compra y Procesamiento de Pedido

```mermaid
sequenceDiagram
    actor Cliente
    actor Sistema
    actor Pasarela as Pasarela de Pagos
    actor Administrador

    Cliente->>Sistema: Añade productos al Carrito (localStorage)
    Cliente->>Sistema: Accede al Checkout, ingresa datos y selecciona Método de Pago
    Sistema->>Sistema: Crea pedido en estado "Pendiente"

    alt Método: TARJETA (Pago Automático)
        Sistema->>Sistema: Reserva temporal de Stock (15 minutos)
        Sistema->>Pasarela: Inicializa transacción y solicita redirección/formulario
        Pasarela-->>Sistema: Retorna URL de pago seguro / tokens
        Sistema-->>Cliente: Redirecciona al portal seguro o abre modal
        Cliente->>Pasarela: Ingresa datos sensibles de tarjeta y confirma cobro
        Pasarela->>Pasarela: Procesa transacción
        alt Transacción Exitosa
            Pasarela->>Sistema: Notificación HTTP POST (Webhook / Callback)
            Note over Sistema: Valida firma de webhook e integridad del payload
            Sistema->>Sistema: Cambia estado de pago a "completado"
            Sistema->>Sistema: Cambia estado del pedido a "PAGADO"
            Sistema->>Sistema: Descuenta stock físico de inventario de forma definitiva
            Pasarela-->>Cliente: Redirecciona a pantalla de Retorno Exitoso
            Sistema-->>Cliente: Muestra confirmación de pedido PAGADO y opción de Crear Cuenta
        else Transacción Fallida / Cancelada
            Pasarela->>Sistema: Notifica error en transacción
            Sistema->>Sistema: Cambia estado de pago a "fallido"
            Sistema->>Sistema: Libera stock reservado de vuelta al inventario
            Pasarela-->>Cliente: Redirecciona a pantalla de Retorno Fallido
            Sistema-->>Cliente: Muestra error y habilita botón para intentar con otra tarjeta o método
        end
    else Método: TRANSFERENCIA o DEUNA (Pago Manual)
        Sistema-->>Cliente: Muestra datos de cuentas bancarias de la empresa / Código QR
        Cliente->>Sistema: Sube comprobante de pago (Imagen o PDF)
        Sistema->>Sistema: Cambia estado del pedido a "Validando"
        Sistema->>Administrador: Notifica nuevo pedido pendiente de verificación
        Administrador->>Sistema: Visualiza comprobante en el panel administrativo
        Administrador->>Administrador: Valida fondos directamente en banco/Deuna
        alt Fondos confirmados
            Administrador->>Sistema: Aprueba Pedido
            Sistema->>Sistema: Cambia estado del pedido a "Aprobado"
            Sistema->>Sistema: Descuenta stock físico de inventario de forma definitiva
            Sistema-->>Cliente: Muestra confirmación de despacho y opción de Crear Cuenta
        else Comprobante inválido / fondos no recibidos
            Administrador->>Sistema: Rechaza Pedido (indica causa de rechazo)
            Sistema->>Sistema: Cambia estado del pedido a "Pendiente" (o "Cancelado" si expira)
            Sistema-->>Cliente: Muestra notificación de rechazo e instrucciones para re-subir comprobante
        end
    end
```


## 3. Referencias y Dependencias
*   [01-business/README.md](file:///c:/xampp/htdocs/Almacenes-al-Costo/spec/01-business/README.md)
*   [03-architecture/02-integration-diagrams.md](file:///c:/xampp/htdocs/Almacenes-al-Costo/spec/03-architecture/02-integration-diagrams.md)
