# Documento: Arquitectura General del Sistema

## 1. Objetivos del Documento
Definir los patrones de diseño, componentes técnicos y la estrategia de modularidad/desacoplamiento de la aplicación **Almacenes al Costo**.

## 2. Arquitectura de Software
*   **Modelo Monolítico**: Laravel se encarga de la lógica del servidor, el control de la base de datos (Eloquent ORM) y el renderizado de la UI en el cliente a través de plantillas Blade.
*   **Arquitectura de Pagos Desacoplada (MVP - V1.0)**:
    *   Se implementa el **Patrón Strategy** y el **Patrón Adapter** para aislar el proceso de Checkout de los proveedores de pago específicos.
    *   **`App\Contracts\PaymentGatewayInterface`**: Interfaz unificada que todos los adaptadores de pago deben implementar. Métodos obligatorios:
        *   `initializePayment(\App\Models\Order $order, array $options = []): \App\DTOs\PaymentResponse`: Prepara la transacción y retorna el DTO con el estado inicial y la URL de redirección o tokens del modal.
        *   `handleCallback(\Illuminate\Http\Request $request): \App\DTOs\PaymentResponse`: Procesa el retorno del cliente desde la pasarela en el frontend.
        *   `handleWebhook(\Illuminate\Http\Request $request): \App\DTOs\PaymentResponse`: Procesa la llamada asíncrona servidor-servidor del proveedor de pagos.
    *   **`App\Services\PaymentService`**: Servicio centralizador que interactúa con el Checkout. Resuelve dinámicamente qué adaptador de pago instanciar basándose en la configuración o el método elegido por el cliente. Se encarga de:
        *   Registrar el intento de pago en la tabla `payments`.
        *   Registrar el historial detallado de peticiones en `payment_transactions`.
        *   Actualizar el estado del pedido en la base de datos según la respuesta (`PaymentResponse`).
        *   Despachar eventos del sistema (ej. descontar stock o notificar).
    *   **Adaptadores Concretos**:
        *   `StripeAdapter`: Traduce solicitudes a la API de Stripe, procesa intents y maneja firmas de webhooks de Stripe.
        *   `PayPhoneAdapter`: Genera links de cobro para PayPhone y valida webhooks de cobros aprobados.
        *   `DatafastAdapter`: Integra la pasarela Datafast mediante su API de cobros e integra el motor de control correspondiente.
        *   `KushkiAdapter`: Conecta con Kushki para cobros con tarjetas nacionales e internacionales.
        *   `ManualPaymentAdapter`: Implementación para Transferencia Bancaria y Deuna, la cual no interactúa con APIs externas sino que delega el flujo a la subida física del comprobante por parte del cliente y la posterior validación del Administrador.

## 3. Referencias y Dependencias
*   [03-architecture/README.md](file:///c:/xampp/htdocs/Almacenes-al-Costo/spec/03-architecture/README.md)
*   [06-backend/04-services-helpers.md](file:///c:/xampp/htdocs/Almacenes-al-Costo/spec/06-backend/04-services-helpers.md)
*   [11-decisions/02-adr-pago-manual.md](file:///c:/xampp/htdocs/Almacenes-al-Costo/spec/11-decisions/02-adr-pago-manual.md)
