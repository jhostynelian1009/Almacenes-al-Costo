# Documento: Estructura Física y Mapeo en Laravel

## 1. Objetivos del Documento
Describir la organización física de archivos y directorios en el repositorio de Laravel del proyecto **Almacenes al Costo**.

## 2. Mapa de Directorios Clave
*   `app/Contracts/`: Definición de interfaces (`PaymentGatewayInterface.php`).
*   `app/Services/Payments/`: Lógica de pasarelas y adaptadores concretos (`PaymentService.php`, `StripeAdapter.php`, `PayPhoneAdapter.php`, `DatafastAdapter.php`, `KushkiAdapter.php`, `ManualPaymentAdapter.php`).
*   `app/DTOs/`: Clases de transferencia de datos de pago (`PaymentResponse.php`).
*   `app/Http/Controllers/`: Controladores públicos, incluyendo `PaymentController.php` y `PaymentWebhookController.php`, y el subdirectorio `Admin/` para controladores del panel.
*   `app/Models/`: Modelos de base de datos (`Product.php`, `Category.php`, `Order.php`, `OrderItem.php`, `Payment.php`, `PaymentTransaction.php`, `WebhookLog.php`, `PaymentReceipt.php`, `Promotion.php`, `Setting.php`).
*   `database/migrations/`: Archivos de migración para inicializar las tablas de base de datos relacionales en orden secuencial.
*   `database/seeders/`: Seeders para poblar categorías iniciales, un administrador por defecto, inventario de prueba y configuraciones de pago.
*   `resources/views/`: Carpeta de plantillas Blade subdividida en `layouts/`, `client/` (agregando subcarpeta `payment/` para vistas de éxito, fallo, pendiente) y `admin/`.
*   `storage/app/comprobantes/`: Carpeta privada no indexable donde se guardan los archivos de comprobantes de pago de forma segura.

## 3. Referencias y Dependencias
*   [03-architecture/README.md](file:///c:/xampp/htdocs/Almacenes-al-Costo/spec/03-architecture/README.md)
*   [06-backend/README.md](file:///c:/xampp/htdocs/Almacenes-al-Costo/spec/06-backend/README.md)
*   [07-frontend/README.md](file:///c:/xampp/htdocs/Almacenes-al-Costo/spec/07-frontend/README.md)
