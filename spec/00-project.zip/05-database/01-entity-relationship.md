# Documento: Modelo Entidad-Relación

## 1. Objetivos del Documento
Definir gráficamente las entidades principales del sistema y cómo se relacionan entre sí para soportar los procesos operativos de la tienda.

## 2. Diagrama Entidad-Relación (Conceptual)
```mermaid
erDiagram
    CATEGORIES ||--o{ PRODUCTS : "contiene"
    PRODUCTS ||--o{ INVENTORIES : "tiene"
    PRODUCTS ||--o{ ORDER_ITEMS : "incluye"
    ORDERS ||--o{ ORDER_ITEMS : "posee"
    ORDERS ||--o{ PAYMENTS : "tiene"
    ORDERS }o--|| USERS : "asociada_a (opcional)"
    PAYMENTS ||--o{ PAYMENT_TRANSACTIONS : "registra"
    PAYMENTS ||--|| PAYMENT_RECEIPTS : "tiene (si es manual)"
    PROMOTIONS ||--o{ ORDERS : "aplica_a"

    CATEGORIES {
        int id PK
        string name
        string slug
    }
    PRODUCTS {
        int id PK
        int category_id FK
        string name
        string sku
        text description
        decimal price
        boolean is_active
    }
    INVENTORIES {
        int id PK
        int product_id FK
        int stock
        int min_stock
    }
    ORDERS {
        int id PK
        int user_id FK "nullable"
        string order_number
        string customer_name
        string customer_document
        string customer_phone
        string customer_email
        text shipping_address
        decimal total
        string status "pending, validating, pagado, approved, canceled"
    }
    ORDER_ITEMS {
        int id PK
        int order_id FK
        int product_id FK
        int quantity
        decimal price
    }
    PAYMENTS {
        int id PK
        int order_id FK
        string gateway "stripe, payphone, datafast, kushki, manual"
        string payment_method "card, transfer, deuna"
        decimal amount
        string status "pending, completed, failed, refunded"
        string transaction_id "nullable"
        timestamp created_at
        timestamp updated_at
    }
    PAYMENT_TRANSACTIONS {
        int id PK
        int payment_id FK
        string event_type "request, response, webhook_received, error"
        json payload
        timestamp created_at
    }
    PAYMENT_RECEIPTS {
        int id PK
        int payment_id FK "nullable"
        int order_id FK
        string file_path
        string payment_method "transfer, deuna"
        string transaction_reference
        timestamp uploaded_at
    }
    WEBHOOK_LOGS {
        int id PK
        string gateway
        string event_id "unique"
        json payload
        boolean processed
        timestamp created_at
    }
```


## 3. Referencias y Dependencias
*   [05-database/README.md](file:///c:/xampp/htdocs/Almacenes-al-Costo/spec/05-database/README.md)
*   [05-database/02-schema-definition.md](file:///c:/xampp/htdocs/Almacenes-al-Costo/spec/05-database/02-schema-definition.md)
