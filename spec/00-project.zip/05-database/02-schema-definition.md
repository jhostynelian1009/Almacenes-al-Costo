# Documento: Definición del Esquema Relacional

## 1. Objetivos del Documento
Especificar la definición física de las tablas de la base de datos MySQL, sus atributos y restricciones relacionales.

## 2. Definición de Tablas (DDL Conceptual)

### Tabla: `products`
*   `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY
*   `category_id` INT UNSIGNED FOREIGN KEY REFERENCES `categories(id)`
*   `name` VARCHAR(255) NOT NULL
*   `sku` VARCHAR(50) UNIQUE NOT NULL
*   `description` TEXT NULL
*   `price` DECIMAL(10,2) NOT NULL
*   `image` VARCHAR(255) NULL
*   `is_active` BOOLEAN DEFAULT TRUE
*   `created_at` TIMESTAMP
*   `updated_at` TIMESTAMP

### Tabla: `orders`
*   `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY
*   `user_id` INT UNSIGNED NULL FOREIGN KEY REFERENCES `users(id)` (vínculo opcional si crea cuenta)
*   `order_number` VARCHAR(50) UNIQUE NOT NULL (ej. PED-20260715-001)
*   `customer_name` VARCHAR(255) NOT NULL
*   `customer_document` VARCHAR(20) NOT NULL (Cédula o RUC)
*   `customer_phone` VARCHAR(20) NOT NULL
*   `customer_email` VARCHAR(255) NOT NULL
*   `shipping_address` TEXT NOT NULL
*   `subtotal` DECIMAL(10,2) NOT NULL
*   `tax` DECIMAL(10,2) NOT NULL
*   `discount` DECIMAL(10,2) DEFAULT 0.00
*   `total` DECIMAL(10,2) NOT NULL
*   `status` ENUM('pending', 'validating', 'pagado', 'approved', 'canceled') DEFAULT 'pending'
*   `created_at` TIMESTAMP
*   `updated_at` TIMESTAMP

### Tabla: `payments`
*   `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY
*   `order_id` INT UNSIGNED NOT NULL FOREIGN KEY REFERENCES `orders(id)` ON DELETE CASCADE
*   `gateway` VARCHAR(50) NOT NULL (ej. 'stripe', 'payphone', 'datafast', 'kushki', 'manual')
*   `payment_method` VARCHAR(30) NOT NULL (ej. 'card', 'transfer', 'deuna')
*   `amount` DECIMAL(10,2) NOT NULL
*   `status` ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending'
*   `transaction_id` VARCHAR(150) NULL INDEX (ID provisto por la pasarela)
*   `created_at` TIMESTAMP
*   `updated_at` TIMESTAMP

### Tabla: `payment_transactions`
*   `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY
*   `payment_id` INT UNSIGNED NOT NULL FOREIGN KEY REFERENCES `payments(id)` ON DELETE CASCADE
*   `event_type` ENUM('request', 'response', 'webhook_received', 'error') NOT NULL
*   `payload` JSON NOT NULL (Detalle crudo de la interacción con la pasarela)
*   `created_at` TIMESTAMP

### Tabla: `payment_receipts`
*   `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY
*   `order_id` INT UNSIGNED NOT NULL FOREIGN KEY REFERENCES `orders(id)` ON DELETE CASCADE
*   `payment_id` INT UNSIGNED NULL FOREIGN KEY REFERENCES `payments(id)` ON DELETE SET NULL (Vínculo opcional al pago manual)
*   `file_path` VARCHAR(255) NOT NULL (ruta de almacenamiento privado)
*   `payment_method` ENUM('transfer', 'deuna') NOT NULL
*   `transaction_reference` VARCHAR(100) NULL
*   `uploaded_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP

### Tabla: `webhook_logs`
*   `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY
*   `gateway` VARCHAR(50) NOT NULL
*   `event_id` VARCHAR(150) UNIQUE NOT NULL (Para asegurar idempotencia y evitar reprocesamientos)
*   `payload` JSON NOT NULL
*   `processed` BOOLEAN DEFAULT FALSE
*   `created_at` TIMESTAMP

## 3. Referencias y Dependencias
*   [05-database/README.md](file:///c:/xampp/htdocs/Almacenes-al-Costo/spec/05-database/README.md)
*   [05-database/03-data-dictionary.md](file:///c:/xampp/htdocs/Almacenes-al-Costo/spec/05-database/03-data-dictionary.md)
