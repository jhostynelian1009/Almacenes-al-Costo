# Documento: Especificación de Controladores y Métodos

## 1. Objetivos del Documento
Definir las responsabilidades, métodos y lógica interna esperada para cada controlador de Laravel.

## 2. Métodos y Lógica de Controladores Clave

### `CheckoutController`
*   `index()`: Retorna la vista `client.checkout` inyectando configuraciones iniciales.
*   `store(Request $request)`:
    *   Valida los datos del cliente (nombre, cédula, dirección, etc.) y los items del carrito recibidos.
    *   Genera un código de orden único.
    *   Guarda la orden en la base de datos con estado "pending".
    *   Registra los items comprados en la tabla `order_items`.
    *   Redirecciona a la ruta `order.payment` con el número de orden generado.
*   `registerAfterPurchase(Request $request, $order_number)`:
    *   Valida la contraseña y confirmación.
    *   Crea el usuario en `users` vinculándolo a la orden utilizando los datos del cliente guardados previamente.
    *   Inicia la sesión automática y redirecciona a una pantalla de perfil o historial.

### `PaymentController`
*   `showPaymentDetails($order_number)`: Muestra la pantalla para seleccionar método de pago. Si es manual, inyecta las cuentas bancarias o QR.
*   `processPayment(Request $request, $order_number)`:
    *   Instancia `PaymentService` resolviendo el adaptador correspondiente al método seleccionado (Stripe, PayPhone, Datafast, Kushki).
    *   Genera el registro de intento de pago en la tabla `payments` (estado "pending") y registra la solicitud en `payment_transactions`.
    *   Reserva temporalmente el stock del inventario (15 minutos).
    *   Retorna la URL de redirección segura provista por el adaptador de la pasarela.
*   `handleCallback(Request $request, $gateway)`:
    *   Procesa la respuesta síncrona de retorno del cliente.
    *   Llama al adaptador correspondiente para verificar el estado de la transacción.
    *   Redirecciona al cliente a `/order/{order_number}/confirmation` con el estado final (PAGADO, FALLIDO o PENDIENTE).
*   `uploadReceipt(Request $request, $order_number)`:
    *   Maneja el flujo de pagos manuales (Transferencia/Deuna). Valida y carga el archivo de comprobante mediante `ReceiptUploadService`.

### `PaymentWebhookController`
*   `handleWebhook(Request $request, $gateway)`:
    *   Recibe la notificación asíncrona servidor-servidor de la pasarela de pagos.
    *   Verifica la firma digital de la cabecera HTTP del webhook contra la clave configurada en settings.
    *   Comprueba idempotencia: busca si el `event_id` ya está en `webhook_logs`. Si ya está, responde con un 200 HTTP inmediato para evitar duplicar el proceso.
    *   Si es nuevo, procesa la transacción llamando a `PaymentService::handleWebhook()`.
    *   Actualiza el pago a `completed` o `failed` y el pedido a `PAGADO` o `canceled`.
    *   Si la transacción es exitosa, consolida definitivamente la reducción de stock de inventario.
    *   Responde con un 200 HTTP exitoso al servidor de la pasarela.

### `Admin\OrderController`
*   `index(Request $request)`: Lista los pedidos paginados, permitiendo filtrar por estado (`pending`, `validating`, `pagado`, `approved`, `canceled`).
*   `show($id)`: Retorna la vista con el detalle completo del pedido, la información del cliente, relación con el comprobante (si es manual) o la bitácora de transacciones de la pasarela (si es automático).
*   `approve($id)`:
    *   (Solo para pedidos manuales) Cambia el estado del pedido a `approved` y descuenta stock definitivo.
*   `reject(Request $request, $id)`:
    *   (Solo para pedidos manuales) Cambia el estado del pedido a `canceled` y registra un texto de retroalimentación de rechazo para el cliente.

## 3. Referencias y Dependencias
*   [06-backend/README.md](file:///c:/xampp/htdocs/Almacenes-al-Costo/spec/06-backend/README.md)
*   [06-backend/01-routes-map.md](file:///c:/xampp/htdocs/Almacenes-al-Costo/spec/06-backend/01-routes-map.md)
*   [05-database/02-schema-definition.md](file:///c:/xampp/htdocs/Almacenes-al-Costo/spec/05-database/02-schema-definition.md)
