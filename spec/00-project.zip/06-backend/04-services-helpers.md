# Documento: Servicios y Helpers del Servidor

## 1. Objetivos del Documento
Especificar los servicios y clases auxiliares no integradas en controladores que se encargan de lógicas de soporte y utilidades del sistema.

## 2. Definición de Servicios

### Servicio: `ReceiptUploadService`
*   **Propósito**: Encapsular la subida del archivo física y su vinculación en la base de datos de manera segura.
*   **Métodos**:
    *   `store(UploadedFile $file, Order $order, string $paymentMethod)`:
        *   Genera un nombre único hash.
        *   Mueve el archivo al storage interno privado (`storage/app/comprobantes/`).
        *   Crea o actualiza el registro en la tabla `payment_receipts` vinculándolo a la orden.
        *   Cambia el estado de la orden a `validating`.

### Servicio: `PaymentService`
*   **Propósito**: Orquestar el flujo de transacciones de pago desacoplado del controlador de checkout. Resuelve el adaptador adecuado, procesa registros en DB y ejecuta acciones post-pago.
*   **Métodos**:
    *   `resolveAdapter(string $gateway): PaymentGatewayInterface`: Instancia dinámicamente el adaptador de pasarela (Stripe, PayPhone, Datafast, Kushki, Manual) según el string recibido.
    *   `initialize(Order $order, string $gateway, array $options = []): PaymentResponse`:
        *   Obtiene el adaptador resuelto.
        *   Crea el registro del pago en `payments` con estado "pending".
        *   Invoca `adapter->initializePayment()`.
        *   Registra la petición en `payment_transactions`.
        *   Retorna el `PaymentResponse` obtenido.
    *   `handleCallback(Request $request, string $gateway): PaymentResponse`:
        *   Llama al método `handleCallback()` del adaptador correspondiente.
        *   Registra el log en `payment_transactions`.
        *   Actualiza el estado de la orden y del registro de pago en DB en base a la respuesta.
        *   Retorna el `PaymentResponse`.
    *   `handleWebhook(Request $request, string $gateway): PaymentResponse`:
        *   Llama a `handleWebhook()` del adaptador para validar firma y parsear la respuesta.
        *   Verifica que no exista un webhook duplicado y registra en `webhook_logs` para asegurar idempotencia.
        *   Si es exitoso, actualiza el pago a "completed", la orden a "PAGADO" y descuenta de forma definitiva el inventario físico.
        *   Retorna `PaymentResponse`.

### DTO: `PaymentResponse`
*   **Propósito**: Estandarizar la comunicación de resultados entre los adaptadores de pago y el servicio central.
*   **Atributos**:
    *   `status` (string): Estado resultante ('pending', 'completed', 'failed', 'refunded').
    *   `transactionId` (string|null): ID de transacción único asignado por la pasarela.
    *   `redirectUrl` (string|null): URL segura para redirigir al cliente en caso de requerir autenticación/pago externo.
    *   `message` (string|null): Mensaje de estado descriptivo o detalle de error.
    *   `payload` (array): Datos brutos completos de la respuesta de la pasarela para fines de logging e historial.

## 3. Referencias y Dependencias
*   [06-backend/README.md](file:///c:/xampp/htdocs/Almacenes-al-Costo/spec/06-backend/README.md)
*   [08-security/02-upload-security.md](file:///c:/xampp/htdocs/Almacenes-al-Costo/spec/08-security/02-upload-security.md)
*   [03-architecture/01-system-architecture.md](file:///c:/xampp/htdocs/Almacenes-al-Costo/spec/03-architecture/01-system-architecture.md)
