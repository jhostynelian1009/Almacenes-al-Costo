# Documento: Seguridad en Pagos y Carga de Comprobantes

## 1. Objetivos del Documento
Establecer medidas de seguridad técnica rígidas tanto para la carga física de comprobantes como para la integración de pasarelas de pago en línea, asegurando el cumplimiento de estándares y protegiendo al sistema de inyección de código, fraudes o fugas de información.

## 2. Controles de Seguridad de Carga (Pagos Manuales)
*   **Validación Estricta de Tipo de Archivo**:
    *   No confiar en la extensión provista por el cliente (`$file->getClientOriginalExtension()`).
    *   Forzar la validación de tipo MIME real del archivo (`image/jpeg`, `image/png`, `application/pdf`).
*   **Limitar Tamaño Máximo**:
    *   El archivo no debe exceder los 4MB (`max:4096` en las reglas de Laravel).
*   **Almacenamiento No Indexable**:
    *   Guardar en `storage/app/comprobantes` (no en `public/storage`).
    *   *Importante*: No crear enlaces simbólicos a esta carpeta.
*   **Descarga / Visualización del Administrador**:
    *   Para renderizar el comprobante en el panel administrativo, usar un endpoint de Laravel que lea el archivo y devuelva una respuesta binaria de tipo imagen/pdf (`Storage::response()`).

## 3. Controles de Seguridad para Pasarelas de Pago (Pagos Automáticos)
*   **HTTPS Obligatorio**: Todo el tráfico entre el navegador del cliente, el servidor Laravel y la pasarela de pagos debe transmitirse bajo protocolo cifrado HTTPS (TLS 1.2 o superior).
*   **Cumplimiento PCI-DSS (No almacenamiento de tarjetas)**: 
    *   El servidor de Almacenes al Costo no debe recibir, transmitir, almacenar ni procesar información sensible de tarjetas (número de tarjeta, fecha de expiración, CVV).
    *   Se deben usar tecnologías de formulario seguro tokenizado (ej. Stripe Elements, PayPhone Iframe) donde el ingreso de los datos sensibles se realiza directamente en la infraestructura certificada del proveedor, retornando únicamente un token seguro de un solo uso al servidor de Laravel.
*   **Validación de Firma de Webhooks**:
    *   El endpoint `/api/payment/webhook/{gateway}` debe verificar obligatoriamente la firma digital de la firma HTTP provista en los headers de la solicitud por la pasarela externa usando la clave secreta secreta compartida (Signing Secret) del webhook configurada en settings.
*   **Idempotencia contra Transacciones Duplicadas**:
    *   Para evitar el procesamiento repetido del mismo pago (por ejemplo, reintentos de red de la pasarela), el webhook debe comprobar en la tabla `webhook_logs` si el `event_id` provisto por el gateway ya fue procesado. Si el registro ya existe, responder inmediatamente con un código `HTTP 200 OK` sin modificar datos.
*   **Prevención de manipulación de importes**:
    *   Al inicializar la pasarela, los montos y totales deben calcularse y firmarse estrictamente en el lado del servidor (`PaymentService`) consultando la base de datos MySQL, nunca aceptando valores monetarios pasados directamente por variables modificables de JavaScript en el cliente.

## 4. Referencias y Dependencias
*   [08-security/README.md](file:///c:/xampp/htdocs/Almacenes-al-Costo/spec/08-security/README.md)
*   [06-backend/04-services-helpers.md](file:///c:/xampp/htdocs/Almacenes-al-Costo/spec/06-backend/04-services-helpers.md)
*   [03-architecture/01-system-architecture.md](file:///c:/xampp/htdocs/Almacenes-al-Costo/spec/03-architecture/01-system-architecture.md)
